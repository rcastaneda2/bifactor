### R code from vignette source 'RcppArmadillo-intro.Rnw'

###################################################
### code chunk number 1: RcppArmadillo-intro.Rnw:68-70
###################################################
prettyVersion <- packageDescription("RcppArmadillo")$Version #$
prettyDate <- format(Sys.Date(), "%B %e, %Y")


